﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace SzNPProjects
{
    public class RichListViewColumn
    {
        public int Width { get; set; }
        public string Text { get; set; }
    }
}
